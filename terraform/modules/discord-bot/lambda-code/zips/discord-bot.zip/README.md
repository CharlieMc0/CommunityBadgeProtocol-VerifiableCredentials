# whitelistPy

## TODO 

This was based on the two  by https://github.com/pstefa1707/whitelistPy and https://oozio.medium.com/serverless-discord-bot-55f95f26f743



Whitelist Manager is a discord bot designed to assist you in gathering wallet addresses for NFT drops.
After configuring the discord bot, users who are 'whitelisted' will be able to record their crypto addresses which you can then download as a CSV.
Note, the config must be filled out before the bot will work.
